<form action="forgot_password_process.php" method="POST">
    <input type="email" name="email" placeholder="Masukkan email" required>
    <button type="submit">Kirim</button>
</form>